package com.jarvis.asistente;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {

    private static final int PERMISOS = 100;
    // Prefijo de país para números de 10 dígitos en WhatsApp (57 = Colombia). Cámbialo si hace falta.
    private static final String PREFIJO_PAIS = "57";

    private OrbView orbe;
    private TextView txtEstado;
    private TextView txtOrden;
    private Button btnHablar;

    private SpeechRecognizer reconocedor;
    private TextToSpeech tts;
    private boolean ttsListo = false;
    private boolean escuchando = false;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        orbe = findViewById(R.id.orbe);
        txtEstado = findViewById(R.id.txtEstado);
        txtOrden = findViewById(R.id.txtOrden);
        btnHablar = findViewById(R.id.btnHablar);

        View.OnClickListener alTocar = v -> alternarEscucha();
        btnHablar.setOnClickListener(alTocar);
        orbe.setOnClickListener(alTocar);

        pedirPermisos();
        tts = new TextToSpeech(this, this);
    }

    // ---------- Permisos ----------

    private boolean tiene(String permiso) {
        return checkSelfPermission(permiso) == PackageManager.PERMISSION_GRANTED;
    }

    private void pedirPermisos() {
        String[] todos = {
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_CONTACTS
        };
        ArrayList<String> faltan = new ArrayList<>();
        for (String p : todos) {
            if (!tiene(p)) faltan.add(p);
        }
        if (!faltan.isEmpty()) {
            requestPermissions(faltan.toArray(new String[0]), PERMISOS);
        }
    }

    // ---------- Voz de Jarvis (TTS) ----------

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) {
            txtEstado.setText("No pude iniciar la voz");
            return;
        }
        int r = tts.setLanguage(new Locale("es", "CO"));
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(new Locale("es", "ES"));
        }
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String id) {
                ui.post(() -> orbe.setEstado(OrbView.HABLANDO));
            }

            @Override
            public void onDone(String id) {
                ui.post(() -> orbe.setEstado(OrbView.REPOSO));
            }

            @Override
            public void onError(String id) {
                ui.post(() -> orbe.setEstado(OrbView.REPOSO));
            }
        });
        ttsListo = true;
        hablar("Hola, soy Jarvis. ¿En qué te ayudo?");
    }

    private void hablar(String texto) {
        txtEstado.setText(texto);
        if (ttsListo) {
            tts.speak(texto, TextToSpeech.QUEUE_FLUSH, null, "jarvis");
        } else {
            orbe.setEstado(OrbView.REPOSO);
        }
    }

    // ---------- Escucha (reconocimiento de voz) ----------

    private void alternarEscucha() {
        if (escuchando && reconocedor != null) {
            reconocedor.stopListening();
        } else {
            escuchar();
        }
    }

    private void escuchar() {
        if (!tiene(Manifest.permission.RECORD_AUDIO)) {
            pedirPermisos();
            txtEstado.setText("Necesito permiso de micrófono");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            hablar("Este teléfono no tiene reconocimiento de voz disponible.");
            return;
        }
        if (ttsListo) tts.stop();

        if (reconocedor == null) {
            reconocedor = SpeechRecognizer.createSpeechRecognizer(this);
            reconocedor.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle params) {
                    txtEstado.setText("Escuchando...");
                }

                @Override
                public void onBeginningOfSpeech() { }

                @Override
                public void onRmsChanged(float rmsdB) {
                    float n = Math.max(0f, Math.min(1f, (rmsdB + 2f) / 12f));
                    orbe.setNivel(n);
                }

                @Override
                public void onBufferReceived(byte[] buffer) { }

                @Override
                public void onEndOfSpeech() {
                    escuchando = false;
                    orbe.setEstado(OrbView.PENSANDO);
                }

                @Override
                public void onError(int error) {
                    escuchando = false;
                    orbe.setEstado(OrbView.REPOSO);
                    if (error == SpeechRecognizer.ERROR_NO_MATCH
                            || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        txtEstado.setText("No te escuché. Toca para hablar.");
                    } else {
                        txtEstado.setText("Error de voz (" + error + "). Toca para intentar de nuevo.");
                    }
                }

                @Override
                public void onResults(Bundle results) {
                    escuchando = false;
                    ArrayList<String> lista =
                            results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (lista == null || lista.isEmpty()) {
                        orbe.setEstado(OrbView.REPOSO);
                        txtEstado.setText("No te escuché. Toca para hablar.");
                        return;
                    }
                    String texto = lista.get(0);
                    txtOrden.setText("“" + texto + "”");
                    orbe.setEstado(OrbView.PENSANDO);
                    procesar(texto);
                }

                @Override
                public void onPartialResults(Bundle partialResults) {
                    ArrayList<String> lista =
                            partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (lista != null && !lista.isEmpty()) {
                        txtOrden.setText(lista.get(0));
                    }
                }

                @Override
                public void onEvent(int eventType, Bundle params) { }
            });
        }

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CO");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);

        escuchando = true;
        orbe.setEstado(OrbView.ESCUCHANDO);
        txtOrden.setText("");
        reconocedor.startListening(intent);
    }

    // ---------- Motor de órdenes ----------

    private void procesar(String texto) {
        CommandParser.Comando c = CommandParser.analizar(texto);
        switch (c.tipo) {
            case CommandParser.ABRIR_APP:
                abrirApp(c.destino);
                break;
            case CommandParser.LLAMAR:
                llamar(c.destino);
                break;
            case CommandParser.SMS:
                enviarSms(c.destino, c.mensaje);
                break;
            case CommandParser.WHATSAPP:
                enviarWhatsApp(c.destino, c.mensaje);
                break;
            default:
                hablar("No entendí la orden. Prueba: abre WhatsApp, llama a mamá, "
                        + "o manda un mensaje por WhatsApp hola.");
        }
    }

    private void abrirApp(String nombre) {
        if (AppLauncher.abrir(this, nombre)) {
            hablar("Abriendo " + nombre);
        } else {
            hablar("No encontré la aplicación " + nombre);
        }
    }

    private String resolverNumero(String objetivo) {
        if (objetivo == null || objetivo.trim().isEmpty()) return null;
        if (objetivo.matches("[\\d\\s+\\-().]+")) {
            String limpio = objetivo.replaceAll("[^0-9+]", "");
            if (limpio.replace("+", "").length() >= 7) return limpio;
        }
        if (!tiene(Manifest.permission.READ_CONTACTS)) {
            pedirPermisos();
            return null;
        }
        return ContactHelper.buscarNumero(this, objetivo);
    }

    private void llamar(String objetivo) {
        String numero = resolverNumero(objetivo);
        if (numero == null) {
            hablar("No encontré el contacto " + objetivo);
            return;
        }
        if (!tiene(Manifest.permission.CALL_PHONE)) {
            pedirPermisos();
            hablar("Necesito permiso para llamar. Acéptalo y repite la orden.");
            return;
        }
        hablar("Llamando a " + objetivo);
        startActivity(new Intent(Intent.ACTION_CALL, Uri.fromParts("tel", numero, null)));
    }

    private void enviarSms(String destino, String mensaje) {
        if (destino == null) {
            hablar("¿A quién le envío el mensaje?");
            return;
        }
        if (mensaje == null || mensaje.isEmpty()) {
            hablar("¿Qué mensaje quieres enviar?");
            return;
        }
        String numero = resolverNumero(destino);
        if (numero == null) {
            hablar("No encontré el contacto " + destino);
            return;
        }
        if (!tiene(Manifest.permission.SEND_SMS)) {
            pedirPermisos();
            hablar("Necesito permiso para enviar mensajes. Acéptalo y repite la orden.");
            return;
        }
        try {
            SmsManager sm = Build.VERSION.SDK_INT >= 31
                    ? getSystemService(SmsManager.class)
                    : SmsManager.getDefault();
            ArrayList<String> partes = sm.divideMessage(mensaje);
            sm.sendMultipartTextMessage(numero, null, partes, null, null);
            hablar("Mensaje enviado a " + destino);
        } catch (Exception e) {
            hablar("No pude enviar el mensaje.");
        }
    }

    private void enviarWhatsApp(String destino, String mensaje) {
        if (mensaje == null || mensaje.isEmpty()) {
            hablar("¿Qué mensaje quieres enviar por WhatsApp?");
            return;
        }
        String numero = null;
        if (destino != null) {
            numero = resolverNumero(destino);
            if (numero == null) {
                hablar("No encontré el contacto " + destino);
                return;
            }
        }

        Intent intent;
        if (numero != null) {
            String d = numero.replaceAll("[^0-9]", "");
            if (d.length() == 10) d = PREFIJO_PAIS + d;
            intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://wa.me/" + d + "?text=" + Uri.encode(mensaje)));
        } else {
            intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT, mensaje);
        }

        String[] paquetes = {"com.whatsapp", "com.whatsapp.w4b"};
        for (String p : paquetes) {
            intent.setPackage(p);
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
                hablar(destino != null
                        ? "Abriendo WhatsApp con tu mensaje para " + destino + ". Toca enviar."
                        : "Elige el contacto en WhatsApp y toca enviar.");
                return;
            }
        }
        hablar("No encontré WhatsApp instalado.");
    }

    // ---------- Ciclo de vida ----------

    @Override
    protected void onPause() {
        super.onPause();
        if (reconocedor != null) reconocedor.cancel();
        escuchando = false;
        orbe.setEstado(OrbView.REPOSO);
    }

    @Override
    protected void onDestroy() {
        if (reconocedor != null) reconocedor.destroy();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
