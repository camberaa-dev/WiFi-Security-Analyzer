package com.jarvis.asistente;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CommandParser {

    public static final int DESCONOCIDO = 0;
    public static final int ABRIR_APP = 1;
    public static final int LLAMAR = 2;
    public static final int SMS = 3;
    public static final int WHATSAPP = 4;

    public static class Comando {
        public int tipo = DESCONOCIDO;
        public String destino;   // app, nombre de contacto o número
        public String mensaje;   // texto del mensaje
    }

    private static final String CANAL =
            "(?:whatsapp|whats app|wasap|wasa|guasap|sms|mensaje de texto|mensajes|mensaje|texto)";
    private static final String CANAL_WA = ".*\\b(?:whatsapp|whats app|wasap|wasa|guasap)\\b.*";

    private static final Pattern P_JARVIS =
            Pattern.compile("\\s*(?:(?:oye|hey|ok)\\s+)?jarvis\\b[,.\\s]*");

    private static final Pattern P_ABRIR = Pattern.compile(
            "(?:abre|abrir|abri|inicia|iniciar|lanza|lanzar|ejecuta|ejecutar|arranca)\\b\\s*"
                    + "(?:(?:la|el|las|los)\\s+)?(?:(?:aplicacion|app|programa)\\s+)?(?:(?:de|del)\\s+)?");

    private static final Pattern P_LLAMAR = Pattern.compile(
            "(?:llama|llamar|llamale|marca|marcar|telefonea|llamada)\\b\\s*(?:(?:a|al|para)\\s+)?");

    private static final Pattern P_VERBO_MSG = Pattern.compile(
            "(?:manda|mandar|mandale|envia|enviar|enviale|escribe|escribir|escribele|dile|decile)\\b\\s*");

    private static final Pattern P_ARTICULO_CANAL =
            Pattern.compile("(?:(?:un|una|el|los|unos)\\s+)?" + CANAL + "\\b\\s*");

    private static final Pattern P_PREP_CANAL =
            Pattern.compile("(?:por|via|en|de|con|al|a traves de)\\s+" + CANAL + "\\b\\s*");

    private static final Pattern P_INTRO_MSG = Pattern.compile(
            "(?:diciendo|que diga|que dice|que le diga|que le dice)\\b[\\s,:]*");

    // Destinatario + mensaje (grupo 1 = destinatario, grupo 2 = mensaje)
    private static final Pattern P_DEST_NUM = Pattern.compile(
            "^(?:a|para)\\s+(\\+?\\d[\\d\\s\\-]{5,}\\d)\\s*[,:]?\\s*(.*)$");
    private static final Pattern P_DEST_CANAL = Pattern.compile(
            "^(?:a|para)\\s+(.+?)\\s+(?:por|via|en|de|con)\\s+" + CANAL + "\\b[\\s,:]*(.*)$");
    private static final Pattern P_DEST_SEP = Pattern.compile(
            "^(?:a|para)\\s+(.+?)\\s+(?:diciendo|que diga|que dice|que le diga|que le dice)\\b[\\s,:]*(.*)$");
    private static final Pattern P_DEST_DOSP = Pattern.compile(
            "^(?:a|para)\\s+(.+?)\\s*:\\s*(.*)$");
    private static final Pattern P_DEST_PAL = Pattern.compile(
            "^(?:a|para)\\s+((?:mi\\s+)?\\S+)\\s+(.*)$");

    public static Comando analizar(String entrada) {
        Comando c = new Comando();
        if (entrada == null) return c;

        String o = entrada.trim();
        String n = normalizar(o);
        if (n.length() != o.length()) o = n; // seguridad: mantener índices alineados

        int pos = fin(P_JARVIS, n, 0);

        // --- Llamar ---
        int p = fin(P_LLAMAR, n, pos);
        if (p > pos) {
            String d = limpiarDestino(o.substring(p));
            if (!d.isEmpty()) {
                c.tipo = LLAMAR;
                c.destino = d;
                return c;
            }
            return c;
        }

        // --- Abrir app ---
        p = fin(P_ABRIR, n, pos);
        if (p > pos) {
            String app = limpiarDestino(o.substring(p));
            if (!app.isEmpty()) {
                c.tipo = ABRIR_APP;
                c.destino = app;
            }
            return c;
        }

        // --- Mensajes (WhatsApp / SMS) ---
        p = fin(P_VERBO_MSG, n, pos);
        if (p > pos) {
            c.tipo = n.matches(CANAL_WA) ? WHATSAPP : SMS;

            // Quitar "un mensaje", "por whatsapp", etc., en cualquier orden
            boolean cambio = true;
            while (cambio) {
                cambio = false;
                int q = fin(P_ARTICULO_CANAL, n, p);
                if (q == p) q = fin(P_PREP_CANAL, n, p);
                if (q > p) {
                    p = q;
                    cambio = true;
                }
            }

            String resto = n.substring(p);
            String destino = null;
            int inicioMsg = p;

            Pattern[] patrones = {P_DEST_NUM, P_DEST_CANAL, P_DEST_SEP, P_DEST_DOSP, P_DEST_PAL};
            for (Pattern pt : patrones) {
                Matcher m = pt.matcher(resto);
                if (m.matches()) {
                    destino = o.substring(p + m.start(1), p + m.end(1));
                    inicioMsg = p + m.start(2);
                    break;
                }
            }

            int q = fin(P_INTRO_MSG, n, inicioMsg);
            String msg = o.substring(q);

            c.destino = destino == null ? null : limpiarDestino(destino);
            c.mensaje = limpiar(msg);
            return c;
        }

        return c;
    }

    private static int fin(Pattern p, String s, int desde) {
        if (desde >= s.length()) return desde;
        Matcher m = p.matcher(s);
        m.region(desde, s.length());
        return m.lookingAt() ? m.end() : desde;
    }

    private static String normalizar(String s) {
        return Normalizer.normalize(s, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT);
    }

    private static String limpiar(String s) {
        if (s == null) return "";
        return s.replaceAll("[\\s.,;:]+$", "").replaceAll("^[\\s,:;]+", "").trim();
    }

    private static String limpiarDestino(String s) {
        return limpiar(s).replaceAll("(?i)\\s+por favor$", "").trim();
    }
}
