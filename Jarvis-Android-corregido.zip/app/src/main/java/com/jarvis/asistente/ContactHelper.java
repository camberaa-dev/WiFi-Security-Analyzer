package com.jarvis.asistente;

import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract.CommonDataKinds.Phone;

import java.text.Normalizer;
import java.util.Locale;

public class ContactHelper {

    public static String buscarNumero(Context ctx, String nombre) {
        if (nombre == null) return null;

        String completo = normalizar(nombre);
        String sinMi = completo.replaceFirst("^mi\\s+", "");

        String[] proyeccion = {Phone.DISPLAY_NAME, Phone.NUMBER};
        String mejorNumero = null;
        int mejorPuntaje = 0;

        try (Cursor cur = ctx.getContentResolver()
                .query(Phone.CONTENT_URI, proyeccion, null, null, null)) {
            if (cur == null) return null;
            while (cur.moveToNext()) {
                String contacto = normalizar(cur.getString(0));
                String numero = cur.getString(1);
                if (contacto.isEmpty() || numero == null) continue;

                int puntaje = 0;
                if (contacto.equals(completo) || contacto.equals(sinMi)) puntaje = 100;
                else if (contacto.startsWith(sinMi)) puntaje = 80;
                else if (contacto.contains(sinMi)) puntaje = 60;

                if (puntaje > mejorPuntaje) {
                    mejorPuntaje = puntaje;
                    mejorNumero = numero;
                }
            }
        } catch (SecurityException e) {
            return null;
        }
        return mejorNumero;
    }

    private static String normalizar(String s) {
        if (s == null) return "";
        return Normalizer.normalize(s, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT)
                .trim();
    }
}
