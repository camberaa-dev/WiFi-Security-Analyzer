package com.jarvis.asistente;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

public class OrbView extends View {

    public static final int REPOSO = 0;
    public static final int ESCUCHANDO = 1;
    public static final int HABLANDO = 2;
    public static final int PENSANDO = 3;

    private int estado = REPOSO;
    private float nivel = 0f;
    private float objetivo = 0f;
    private float entrada = 0f;
    private float tiempo = 0f;
    private long ultimo = 0;
    private float radio = 100f;

    private final Paint pGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pEsfera = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pAnillo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pLinea = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pNodo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF caja = new RectF();

    private Shader glowShader;
    private Shader esferaShader;
    private DashPathEffect dash;

    public OrbView(Context context) {
        super(context);
        init();
    }

    public OrbView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        pAnillo.setStyle(Paint.Style.STROKE);
        pAnillo.setStrokeCap(Paint.Cap.ROUND);
        pLinea.setStyle(Paint.Style.STROKE);
        pLinea.setStrokeCap(Paint.Cap.ROUND);
        pNodo.setStyle(Paint.Style.FILL);
        pGlow.setStyle(Paint.Style.FILL);
        pEsfera.setStyle(Paint.Style.FILL);
    }

    public void setEstado(int nuevo) {
        estado = nuevo;
        if (nuevo != ESCUCHANDO) entrada = 0f;
    }

    public void setNivel(float n) {
        entrada = Math.max(0f, Math.min(1f, n));
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        float r = Math.min(w, h) * 0.30f;
        radio = r;
        float d = getResources().getDisplayMetrics().density;

        glowShader = new RadialGradient(0, 0, r * 2.4f,
                new int[]{0xAA00E5FF, 0x3300A0FF, 0x00000000},
                new float[]{0.40f, 0.72f, 1f}, Shader.TileMode.CLAMP);
        esferaShader = new RadialGradient(-r * 0.30f, -r * 0.35f, r * 1.35f,
                new int[]{0xFFA6F7FF, 0xFF0A74E0, 0xFF021B40},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP);
        dash = new DashPathEffect(new float[]{10f * d, 8f * d}, 0f);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        long ahora = SystemClock.uptimeMillis();
        float dt = ultimo == 0 ? 0.016f : Math.min(0.05f, (ahora - ultimo) / 1000f);
        ultimo = ahora;
        tiempo += dt;

        switch (estado) {
            case ESCUCHANDO:
                objetivo = 0.15f + 0.85f * entrada;
                break;
            case HABLANDO:
                objetivo = 0.30f + 0.70f * Math.abs(
                        (float) (Math.sin(tiempo * 9.0) * Math.sin(tiempo * 5.3 + 1.0)));
                break;
            case PENSANDO:
                objetivo = 0.25f + 0.15f * (float) Math.sin(tiempo * 6.0);
                break;
            default:
                objetivo = 0.06f + 0.05f * (float) Math.sin(tiempo * 1.6);
        }
        nivel += (objetivo - nivel) * Math.min(1f, dt * 10f);
        entrada *= Math.max(0f, 1f - dt * 2f);

        float d = getResources().getDisplayMetrics().density;
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float esc = 1f + 0.10f * nivel;
        float R = radio * esc;
        float vel = (estado == PENSANDO ? 3.0f : 1.0f) * (1f + nivel);

        canvas.save();
        canvas.translate(cx, cy);

        // Resplandor
        canvas.save();
        float sg = 1f + 0.30f * nivel;
        canvas.scale(sg, sg);
        pGlow.setShader(glowShader);
        canvas.drawCircle(0, 0, radio * 2.4f, pGlow);
        canvas.restore();

        // Esfera
        canvas.save();
        canvas.scale(esc, esc);
        pEsfera.setShader(esferaShader);
        canvas.drawCircle(0, 0, radio, pEsfera);
        canvas.restore();

        // Circuitos
        pLinea.setStrokeWidth(1.4f * d);
        for (int i = 0; i < 24; i++) {
            float a = (float) (i * (Math.PI * 2 / 24)) + tiempo * 0.12f * vel;
            float a2 = a + ((i % 2 == 0) ? 0.12f : -0.12f);
            float c0 = (float) Math.cos(a), s0 = (float) Math.sin(a);
            float c2 = (float) Math.cos(a2), s2 = (float) Math.sin(a2);
            float x0 = c0 * R * 0.20f, y0 = s0 * R * 0.20f;
            float x1 = c0 * R * 0.52f, y1 = s0 * R * 0.52f;
            float x2 = c2 * R * 0.72f, y2 = s2 * R * 0.72f;
            float x3 = c2 * R * 0.92f, y3 = s2 * R * 0.92f;

            float pulso = 0.5f + 0.5f * (float) Math.sin(tiempo * 3f + i);
            int alfa = Math.min(255, (int) (90 + 120 * pulso * (0.4f + nivel)));
            pLinea.setColor(Color.argb(alfa, 0, 229, 255));
            canvas.drawLine(x0, y0, x1, y1, pLinea);
            canvas.drawLine(x1, y1, x2, y2, pLinea);
            canvas.drawLine(x2, y2, x3, y3, pLinea);

            pNodo.setColor(Color.argb(Math.min(255, alfa + 40), 160, 250, 255));
            canvas.drawCircle(x3, y3, (2f + 1.5f * pulso) * d, pNodo);
        }

        // Núcleo brillante
        pNodo.setColor(Color.argb(Math.min(255, (int) (150 + 100 * nivel)), 255, 255, 255));
        canvas.drawCircle(0, 0, R * 0.10f * (1f + nivel), pNodo);

        // Anillos
        float ex = 0.07f * nivel;

        pAnillo.setPathEffect(null);
        pAnillo.setStrokeWidth(3f * d);
        pAnillo.setColor(Color.argb(210, 0, 229, 255));
        canvas.save();
        canvas.rotate(tiempo * 40f * vel);
        float r1 = R * (1.10f + ex);
        caja.set(-r1, -r1, r1, r1);
        canvas.drawArc(caja, 0f, 260f, false, pAnillo);
        canvas.restore();

        pAnillo.setStrokeWidth(2f * d);
        pAnillo.setColor(Color.argb(160, 10, 132, 255));
        pAnillo.setPathEffect(dash);
        canvas.save();
        canvas.rotate(-tiempo * 25f * vel);
        canvas.drawCircle(0, 0, R * (1.24f + ex), pAnillo);
        canvas.restore();

        pAnillo.setPathEffect(null);
        pAnillo.setStrokeWidth(2f * d);
        pAnillo.setColor(Color.argb(140, 0, 229, 255));
        canvas.save();
        canvas.rotate(tiempo * 15f * vel);
        float r3 = R * (1.40f + ex * 1.5f);
        caja.set(-r3, -r3, r3, r3);
        for (int k = 0; k < 3; k++) {
            canvas.drawArc(caja, k * 120f, 70f, false, pAnillo);
        }
        canvas.restore();

        // Partículas exteriores
        for (int i = 0; i < 40; i++) {
            float a = (float) (i * Math.PI * 2 / 40) - tiempo * 0.2f * vel;
            float rd = R * (1.58f + 0.03f * (float) Math.sin(tiempo * 2f + i));
            int al = Math.min(255, (int) (70 + 150 * nivel
                    * (0.5f + 0.5f * (float) Math.sin(tiempo * 4f + i * 2f))));
            pNodo.setColor(Color.argb(al, 0, 229, 255));
            canvas.drawCircle((float) Math.cos(a) * rd, (float) Math.sin(a) * rd, 1.6f * d, pNodo);
        }

        canvas.restore();
        postInvalidateOnAnimation();
    }
}
